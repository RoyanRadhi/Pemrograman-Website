-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 10.4.27-MariaDB - mariadb.org binary distribution
-- OS Server:                    Win64
-- HeidiSQL Versi:               12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Membuang struktur basisdata untuk db_toko
CREATE DATABASE IF NOT EXISTS `db_toko` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `db_toko`;

-- membuang struktur untuk table db_toko.provinsi
CREATE TABLE IF NOT EXISTS `provinsi` (
  `id_prov` char(2) NOT NULL,
  `nama` tinytext NOT NULL,
  `ongkir` int(11) NOT NULL,
  PRIMARY KEY (`id_prov`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Membuang data untuk tabel db_toko.provinsi: ~34 rows (lebih kurang)
INSERT INTO `provinsi` (`id_prov`, `nama`, `ongkir`) VALUES
	('11', 'Aceh', 20000),
	('12', 'Sumatera Utara', 19500),
	('13', 'Sumatera Barat', 19500),
	('14', 'Riau', 20000),
	('15', 'Jambi', 18000),
	('16', 'Sumatera Selatan', 19500),
	('17', 'Bengkulu', 18000),
	('18', 'Lampung', 19000),
	('19', 'Kepulauan Bangka Belitung', 20000),
	('21', 'Kepulauan Riau', 20000),
	('31', 'DKI Jakarta', 18000),
	('32', 'Jawa Barat', 15000),
	('33', 'Jawa Tengah', 12000),
	('34', 'DI Yogyakarta', 12000),
	('35', 'Jawa Timur', 10000),
	('36', 'Banten', 15000),
	('51', 'Bali', 20000),
	('52', 'Nusa Tenggara Barat', 25000),
	('53', 'Nusa Tenggara Timur', 25000),
	('61', 'Kalimantan Barat', 20000),
	('62', 'Kalimantan Tengah', 22000),
	('63', 'Kalimantan Selatan', 22000),
	('64', 'Kalimantan Timur', 23000),
	('65', 'Kalimantan Utara', 23000),
	('71', 'Sulawesi Utara', 25000),
	('72', 'Sulawesi Tengah', 25000),
	('73', 'Sulawesi Selatan', 25000),
	('74', 'Sulawesi Tenggara', 25000),
	('75', 'Gorontalo', 22000),
	('76', 'Sulawesi Barat', 25000),
	('81', 'Maluku', 25000),
	('82', 'Maluku Utara', 25000),
	('91', 'Papua Barat', 30000),
	('92', 'Papua', 30000);

-- membuang struktur untuk table db_toko.tb_admin
CREATE TABLE IF NOT EXISTS `tb_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Membuang data untuk tabel db_toko.tb_admin: ~0 rows (lebih kurang)
INSERT INTO `tb_admin` (`id`, `username`, `password`, `nama`) VALUES
	(1, 'mod', 'mod', '@ROYAN');

-- membuang struktur untuk table db_toko.tb_pelanggan
CREATE TABLE IF NOT EXISTS `tb_pelanggan` (
  `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `telepon` varchar(30) NOT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Membuang data untuk tabel db_toko.tb_pelanggan: ~2 rows (lebih kurang)
INSERT INTO `tb_pelanggan` (`id_pelanggan`, `email`, `password`, `nama_pelanggan`, `telepon`) VALUES
	(19, 'royan@gmail.com', 'royan', 'Roeyan Radhi', '089509141829'),
	(20, 'royan2@gmail.com', 'royan', 'Roeyyan Radhi', '089509141829'),
	(21, 'test@gmail.com', 'royan', 'Hairunnisa', '08125669734');

-- membuang struktur untuk table db_toko.tb_pembayaran
CREATE TABLE IF NOT EXISTS `tb_pembayaran` (
  `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `bank` varchar(30) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(30) NOT NULL,
  PRIMARY KEY (`id_pembayaran`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Membuang data untuk tabel db_toko.tb_pembayaran: ~4 rows (lebih kurang)
INSERT INTO `tb_pembayaran` (`id_pembayaran`, `id_pembelian`, `nama`, `bank`, `jumlah`, `tanggal`, `bukti`) VALUES
	(16, 33, 'rr', 'dana', 123, '2024-03-21', '20240321063945put.PNG'),
	(17, 34, 'RUYAN', 'DANA', 34500, '2024-03-21', '20240321070100dee1.PNG'),
	(18, 36, 'royan', 'er', 2500, '2024-03-22', '20240322015039upr.png'),
	(19, 38, 'Royann', 'BRI MOBILE', 2500, '2024-03-22', '20240322022002upr.png');

-- membuang struktur untuk table db_toko.tb_pembelian
CREATE TABLE IF NOT EXISTS `tb_pembelian` (
  `id_pembelian` int(11) NOT NULL AUTO_INCREMENT,
  `id_pelanggan` int(11) NOT NULL,
  `id_prov` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `tarif` int(11) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id_pembelian`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Membuang data untuk tabel db_toko.tb_pembelian: ~9 rows (lebih kurang)
INSERT INTO `tb_pembelian` (`id_pembelian`, `id_pelanggan`, `id_prov`, `tanggal_pembelian`, `total_pembelian`, `tarif`, `alamat`, `status`) VALUES
	(31, 19, 12, '2024-03-21', 22000, 19500, '', 'Pending'),
	(32, 19, 0, '2024-03-21', 2500, 0, '', 'Pending'),
	(33, 20, 12, '2024-03-21', 22000, 19500, 'Rta', 'Produk di Terima'),
	(34, 20, 13, '2024-03-21', 34500, 19500, 'dd', 'Sedang di Kirim'),
	(35, 20, 12, '2024-03-21', 28000, 19500, 'awww', 'Pending'),
	(36, 19, 11, '2024-03-22', 22500, 20000, 'anu', 'Produk di Terima'),
	(37, 19, 0, '2024-03-22', 5000, 0, 'jurusan teknik kelas 3 ruangan 1', 'Pending'),
	(38, 21, 0, '2024-03-22', 10000, 0, 'Kelas audit ruangan 1 sebelah kanan', 'Produk di Terima'),
	(39, 21, 0, '2024-03-22', 10000, 0, 'hh', 'Pending'),
	(40, 19, 0, '2024-03-23', 2500, 0, '', 'Pending');

-- membuang struktur untuk table db_toko.tb_pembelian_produk
CREATE TABLE IF NOT EXISTS `tb_pembelian_produk` (
  `id_pembelian_produk` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  PRIMARY KEY (`id_pembelian_produk`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Membuang data untuk tabel db_toko.tb_pembelian_produk: ~8 rows (lebih kurang)
INSERT INTO `tb_pembelian_produk` (`id_pembelian_produk`, `id_pembelian`, `id_produk`, `jumlah`) VALUES
	(39, 31, 13, 1),
	(40, 32, 13, 1),
	(41, 33, 13, 1),
	(42, 34, 20, 5),
	(43, 35, 16, 1),
	(44, 35, 13, 1),
	(45, 36, 13, 1),
	(46, 37, 14, 1),
	(47, 38, 18, 1),
	(48, 39, 18, 1),
	(49, 40, 13, 1);

-- membuang struktur untuk table db_toko.tb_produk
CREATE TABLE IF NOT EXISTS `tb_produk` (
  `id_produk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_produk` varchar(40) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `berat_produk` int(11) NOT NULL,
  `foto_produk` varchar(40) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  PRIMARY KEY (`id_produk`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Membuang data untuk tabel db_toko.tb_produk: ~11 rows (lebih kurang)
INSERT INTO `tb_produk` (`id_produk`, `nama_produk`, `harga_produk`, `berat_produk`, `foto_produk`, `deskripsi_produk`) VALUES
	(13, 'Pulpen joyko', 2500, 1, 'pulpen mid budget.jpg', 'Puplen Dana Pelajar'),
	(14, 'Tinta Spidol', 5000, 1, 'tinta snow.jpg', 'Tinta Snowman'),
	(15, 'Pulpen Blive', 3000, 1, 'blive.jpg', 'Pulpen para Sultan menyala'),
	(16, 'penghapus biasa', 6000, 1, 'penghapus biasa.jpg', 'Penghapus dana pelajar'),
	(18, 'Kalkulator', 10000, 2, 'kalkulator.JPG', 'Kalkulator untuk yang susah berhitung hehe'),
	(19, 'Pensil FaberCastel', 1500, 1, 'pensil 2b.JPG', 'Pensil biasa tpi bukan biasa'),
	(20, 'Kenko Tipex', 3000, 1, 'tipex.jpeg', 'Tipex untuk menghapus gamon'),
	(21, 'Penggaris Siku', 15000, 5, 'penggaris siku.jpg', 'Penggaris Siku'),
	(22, 'Rendang', 10000, 5, 'rendang.jpg', 'Rendang Lezat Asal Ngawi'),
	(23, 'Nguwawor', 100000000, 100, 'nguwawor1.gif', 'Aawokawokok'),
	(24, 'Ngawur PArt 2', 300000, 5, 'nguwawor.gif', 'Ngawur cakkkk'),
	(25, 'Penghapus sultan ', 5000, 5, 'penghapus papan tulis sultan.jpg', 'penghapus ytta');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
