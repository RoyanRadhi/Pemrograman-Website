# Online-Shop-Dengan-PHP
Pengembangan online shop yang dibangun dengan PHP Native.
Alur aplikasi / sistem :
  - Pelanggan melakukan register/daftar ke sistem
  - Pelanggan memassukkan produk dalam keranjang belanja
  - pelanggan melakukan checkout
  - Pembayaran dilakakukan masih via manual, yaitu pelanggan transfer ke Bank penjual
  - Transaksi selesai
