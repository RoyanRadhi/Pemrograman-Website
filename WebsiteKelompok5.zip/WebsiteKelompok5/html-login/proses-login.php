<?php  
session_start();
$koneksi = new mysqli("localhost", "root", "","db_toko");

if (isset($_POST["login"]) && empty($_SESSION["keranjang"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $ambil = $koneksi->query("SELECT * FROM tb_pelanggan WHERE email='$email' AND password='$password'");
    $akunygcocok = $ambil->num_rows;

    if ($akunygcocok == 1) {
        $akun = $ambil->fetch_assoc();
        $_SESSION["pelanggan"] = $akun;
        echo "<script>alert('Selamat Datang di Toko Kami');</script>";
        echo "<script>location='../index.php';</script>";  
    } else {
        echo "<script>alert('Anda Gagal Login, Periksa Username atau Password Anda');</script>";
        echo "<script>location='index.html';</script>";
    }
} else if (isset($_POST["login"]) && isset($_SESSION["keranjang"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $ambil = $koneksi->query("SELECT * FROM tb_pelanggan WHERE email='$email' AND password='$password'");
    $akunygcocok = $ambil->num_rows;

    if ($akunygcocok == 1) {
        $akun = $ambil->fetch_assoc();
        $_SESSION["pelanggan"] = $akun;
        echo "<script>alert('Selamat Datang di Toko Kami');</script>";
        echo "<script>location='../checkout.php';</script>";  
    } else {
        echo "<script>alert('Anda Gagal Login, Periksa Username atau Password Anda');</script>";
        echo "<script>location='index.html';</script>";
    }
}

?>