<?php  
session_start();
$koneksi = new mysqli("localhost", "root", "","db_toko");

if (isset($_POST["daftar"]) && empty($_SESSION["keranjang"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];
    $nama = $_POST["nama"];
    $hp = $_POST["hp"];

    $sql = $koneksi->query("INSERT INTO tb_pelanggan (email, password, nama_pelanggan, telepon) VALUES ('$email', '$password', '$nama', '$hp')");

    if($sql === true){
        echo "<script>alert('PENDAFTARAN BERHASIL');</script> ";
        echo "<script>location='index.html';</script> " ;
    } else {
        echo "Gagal: ". $koneksi->error;
    }
} 
?>