<?php 
session_start();
$koneksi = new mysqli("localhost", "root", "","db_toko");

// Pastikan session 'pelanggan' sudah dimulai dan 'id' sudah di-set sebelum mengakses halaman ini
if (!isset($_SESSION['pelanggan']) || !isset($_SESSION['pelanggan']['id_pelanggan'])) {
    echo "<script>alert('Silakan login terlebih dahulu');</script>";
    echo "<script>location='index.html';</script>";
    exit; // Menghentikan eksekusi kode lebih lanjut jika pengguna belum login
}

$id_pembayaran = $_GET['id'];
$ambil = $koneksi->query("SELECT * FROM tb_pembelian WHERE id_pembelian='$id_pembayaran'");
$pecah = $ambil->fetch_assoc();

// MENDAPATKAN ID PELANGGAN YANG BELI
$id_pelanggan_beli = $pecah['id_pelanggan'];

// MENDAPATKAN ID PELANGGAN YG LOGIN
$id_pelanggan_login = $_SESSION['pelanggan']['id_pelanggan'];

// KONDISI JIKA ID PELANGGAN BELI != ID PELANGGAN LOGIN
if ($id_pelanggan_beli !== $id_pelanggan_login) {
    echo "<script>alert('TIDAK DAPAT MENGAKSES');</script>";
    echo "<script>location='../riwayat.php';</script>";
    exit; // Menghentikan eksekusi kode lebih lanjut jika pengguna tidak diizinkan mengakses halaman ini
}

if (isset($_POST['kirim'])) {
    $namabukti = $_FILES['bukti']['name'];
    $lokasibukti = $_FILES['bukti']['tmp_name'];
    $namafoto = date('Ymdhis').$namabukti;
    move_uploaded_file($lokasibukti, "foto_bukti/$namafoto");

    $nama = $_POST['nama'];
    $bank = $_POST['bank'];
    $jumlah = $_POST['jumlah'];
    $tanggal = date('Y-m-d');

    $koneksi->query("INSERT INTO tb_pembayaran (id_pembelian, nama, bank, jumlah, tanggal, bukti)
                     VALUES ('$id_pembayaran', '$nama', '$bank', '$jumlah', '$tanggal', '$namafoto')");

    $koneksi->query("UPDATE tb_pembelian SET status='Menunggu Konfirmasi' WHERE id_pembelian='$id_pembayaran'");

    echo "<script>alert('TERIMAKASIH SUDAH MELAKUKAN PEMBAYARAN');</script>";
    echo "<script>location = '../riwayat.php';</script>";
}
?>
